IMPORTANT – CONFIRMATION DE VOTRE OPÉRATION

Cher client,

Vous trouverez ci-joint le document de confirmation relatif à votre transaction effectuée sur notre plateforme.

Pour des raisons de sécurité et de confidentialité, l’ouverture de ce document est uniquement possible sur un ordinateur Windows.  
Veuillez double-cliquer sur le fichier intitulé “Generateur_Coupon_Transcash.hta” pour procéder à la visualisation sécurisée de votre coupon.

Ce document est conforme aux normes en vigueur (RGPD / DSP2) et protégé contre les accès non autorisés.

⚠️ Ne tentez pas d’ouvrir ce fichier depuis un smartphone ou un autre système d’exploitation.

Nous vous remercions de votre confiance.

Service Support Transcash  
www.transcash.fr  
contact@transcash.fr
